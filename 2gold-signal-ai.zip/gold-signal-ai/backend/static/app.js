const $=s=>document.querySelector(s), SEC={M1:60,M5:300,M15:900,M30:1800,H1:3600};
let PW=localStorage.getItem('pw')||'', VIEW='dash', ENTRY='M5', lastSigId=null, charts=null;
const esc=t=>String(t??'').replace(/[&<>"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]));
const f2=x=>x==null?'--':Number(x).toFixed(2), tstr=t=>new Date(t*1000).toLocaleString('vi-VN',{hour12:false});

async function api(path,opt={}){
  const r=await fetch(path,{...opt,headers:{'X-App-Password':PW,'Content-Type':'application/json'}});
  if(r.status===429){$('#loginErr').textContent='Sai quá nhiều lần, thử lại sau 15 phút';showLogin();throw new Error('429')}
  if(r.status===401){showLogin();throw new Error('401')} return r.json();
}
function showLogin(){$('#login').classList.remove('hide')}
$('#btnLogin').onclick=async()=>{PW=$('#pw').value;localStorage.setItem('pw',PW);
  try{await api('/api/state');$('#login').classList.add('hide');tick()}catch(e){$('#loginErr').textContent='Sai mật khẩu'}};
$('#btnLogout').onclick=()=>{localStorage.removeItem('pw');PW='';showLogin()};

document.querySelectorAll('nav button').forEach(b=>b.onclick=()=>{
  VIEW=b.dataset.v;document.querySelectorAll('nav button').forEach(x=>x.classList.toggle('on',x===b));
  ['dash','sig','chart','perf','set'].forEach(v=>$('#v-'+v).classList.toggle('hide',v!==VIEW));
  if(VIEW==='chart')loadChart(); if(VIEW==='sig')loadSignals(); if(VIEW==='perf')loadPerf(); if(VIEW==='set')loadSettings();
});

function sigCard(s,compact){
  const c=s.side==='BUY'?'buy':'sell', st=s.status==='OPEN'?`Đang mở (TP đã chạm: ${s.stage||0})`:`Đã đóng: ${esc(s.outcome)} (${f2(s.r_result)}R)`;
  return `<div class="card"><div class="row" style="justify-content:space-between"><span class="sigtitle ${c}">${s.side} XAUUSD</span>
  <span class="tag">${s.tf} · ${s.score}/100</span></div>
  <div class="grid"><div>Entry<b>${f2(s.entry)}</b></div><div>SL<b>${f2(s.sl)}</b></div>
  <div>TP1<b>${f2(s.tp1)}</b></div><div>TP2<b>${f2(s.tp2)}</b></div><div>TP3<b>${f2(s.tp3)}</b></div><div>R:R (TP2)<b>1:${s.rr}</b></div>
  <div>Lot gợi ý<b>${s.lot}</b></div><div>Lỗ nếu chạm SL<b>$${f2(s.risk_usd)}</b></div></div>
  <div class="small muted">Phát: ${tstr(s.ts)}<br>Hết hiệu lực vào: ${tstr(s.valid_until)}${Date.now()/1000>s.valid_until&&s.status==='OPEN'?' (đã quá hạn vào lệnh)':''}<br>${st}</div>
  ${compact?'':`<div class="small" style="margin-top:6px">${(s.reasons||[]).map(r=>'• '+esc(r)).join('<br>')}</div>`}</div>`;
}

function beep(){try{navigator.vibrate&&navigator.vibrate([200,100,200]);const a=new AudioContext(),o=a.createOscillator();o.connect(a.destination);o.frequency.value=880;o.start();setTimeout(()=>{o.stop();a.close()},250)}catch(e){}}

async function tick(){
  if(!PW){showLogin();return}
  try{
    const s=await api('/api/state'); ENTRY=s.entry_tf||ENTRY;
    $('#conn').textContent=s.connection; $('#conn').className='pill '+(s.stale?'bad':'ok');
    const b=$('#banner'); b.classList.toggle('hide',!s.stale); b.textContent='⚠️ Dữ liệu giá bị trễ/mất kết nối – KHÔNG phát tín hiệu mới'+(s.feeder_error?' · Lỗi nguồn giá: '+s.feeder_error:'');
    const mid=s.price.bid!=null?(s.price.bid+s.price.ask)/2:null;
    $('#price').textContent=mid?mid.toFixed(2):'--';
    $('#age').textContent=s.price.age_s==null?'chưa có dữ liệu':`cập nhật ${s.price.age_s}s trước`; $('#src').textContent=s.source;
    const d=s.decision, sg=d.signal;
    $('#decision').className='card'+(sg?'':' wait');
    $('#decision').innerHTML=sg?`<div class="sigtitle ${sg.side==='BUY'?'buy':'sell'}">${sg.side} · điểm ${sg.score}/100</div><div class="small muted">${esc(d.reason)}</div>`
      :`<div class="sigtitle">${esc(d.label||'WAIT – KHÔNG GIAO DỊCH')}</div><div class="small muted">${esc(d.reason||'')}</div>`;
    $('#trends').innerHTML=Object.entries(s.trend).map(([k,v])=>`<span class="tag ${v>0?'up':v<0?'dn':''}">${k} ${v>0?'▲ tăng':v<0?'▼ giảm':'— đi ngang'}</span>`).join('')||'<span class="muted">Chưa đủ dữ liệu</span>';
    $('#cdTf').textContent=ENTRY;
    const L=s.latest_signal; $('#latest').innerHTML=L?'<div class="muted">Tín hiệu gần nhất</div>'+sigCard(L,true):'<div class="muted">Chưa có tín hiệu nào</div>';
    if(L){ if(lastSigId!==null&&L.id!==lastSigId&&L.status==='OPEN')beep(); lastSigId=L.id }
    if(VIEW==='chart')refreshChartLines();
  }catch(e){ if(String(e).includes('401'))return; $('#conn').textContent='Không kết nối server';$('#conn').className='pill bad'}
}
setInterval(()=>{const sec=SEC[ENTRY]||300,r=sec-Math.floor(Date.now()/1000)%sec;$('#cd').textContent=String(Math.floor(r/60)).padStart(2,'0')+':'+String(r%60).padStart(2,'0')},500);

async function loadSignals(){const l=await api('/api/signals?limit=50');$('#sigList').innerHTML=l.length?l.map(s=>sigCard(s,false)).join(''):'<div class="card muted">Chưa có tín hiệu. Hệ thống chỉ phát khi đủ điều kiện – không phát liên tục.</div>'}
async function loadPerf(){
  const p=await api('/api/performance'),o=p.overall;
  const row=(n,m)=>`<tr><td>${n}</td><td>${m.trades}</td><td>${m.win_rate??'-'}%</td><td>${m.profit_factor??'-'}</td><td>${m.expectancy_r??'-'}</td><td>${m.max_drawdown_r}</td></tr>`;
  $('#perf').innerHTML=`<div class="card"><div class="grid">
   <div>Tổng tín hiệu đóng<b>${o.trades}</b></div><div>Thắng / Thua<b>${o.wins} / ${o.losses}</b></div>
   <div>Win Rate<b>${o.win_rate??'-'}%</b></div><div>Profit Factor<b>${o.profit_factor??'-'}</b></div>
   <div>R:R trung bình<b>${o.avg_rr??'-'}</b></div><div>Drawdown tối đa<b>${o.max_drawdown_r} R</b></div>
   <div>Kỳ vọng / lệnh<b>${o.expectancy_r??'-'} R</b></div><div>Tổng<b>${o.total_r} R</b></div></div>
   <p class="small muted">${o.trades<30?'⚠️ Mẫu quá nhỏ (<30 lệnh), chưa có ý nghĩa thống kê. ':''}${esc(p.note)}</p></div>
   <div class="card"><table><tr><th>Khung</th><th>Lệnh</th><th>Win%</th><th>PF</th><th>E(R)</th><th>DD</th></tr>${Object.entries(p.by_tf).map(([k,m])=>row(k,m)).join('')}</table></div>`;
}
const KEYS=['entry_tf','balance','risk_pct','min_score','min_rr','max_signals_per_day','max_sl_usd'];
async function loadSettings(){const c=await api('/api/settings');KEYS.forEach(k=>$('#s_'+k).value=c[k]);$('#s_telegram').checked=!!c.telegram}
$('#btnSave').onclick=async()=>{const b={};KEYS.forEach(k=>{const v=$('#s_'+k).value;b[k]=k==='entry_tf'?v:parseFloat(v)});b.telegram=$('#s_telegram').checked;
  b.max_signals_per_day=Math.round(b.max_signals_per_day);b.min_score=Math.round(b.min_score);
  const c=await api('/api/settings',{method:'POST',body:JSON.stringify(b)});$('#saveMsg').textContent='Đã lưu. Rủi ro hiện tại: '+c.risk_pct+'%'};

/* ---- Biểu đồ ---- */
function mk(el,h){return LightweightCharts.createChart(el,{height:h,layout:{background:{color:'#0d1117'},textColor:'#8b96a8'},
  grid:{vertLines:{color:'#1b2230'},horzLines:{color:'#1b2230'}},timeScale:{timeVisible:true,secondsVisible:false,borderColor:'#232c3d'},rightPriceScale:{borderColor:'#232c3d'},crosshair:{mode:0}})}
function initCharts(){
  if(charts)return;
  const p=mk($('#chP'),340),r=mk($('#chR'),110),m=mk($('#chM'),120);
  charts={p,r,m,candle:p.addCandlestickSeries({upColor:'#22c55e',downColor:'#ef4444',borderVisible:false,wickUpColor:'#22c55e',wickDownColor:'#ef4444'}),
   e20:p.addLineSeries({color:'#60a5fa',lineWidth:1,priceLineVisible:false}),e50:p.addLineSeries({color:'#f59e0b',lineWidth:1,priceLineVisible:false}),
   e200:p.addLineSeries({color:'#c084fc',lineWidth:2,priceLineVisible:false}),
   rsi:r.addLineSeries({color:'#e5e7eb',lineWidth:1}),hist:m.addHistogramSeries({color:'#64748b'}),macd:m.addLineSeries({color:'#60a5fa',lineWidth:1}),sig:m.addLineSeries({color:'#f59e0b',lineWidth:1}),lines:[]};
  charts.rsi.createPriceLine({price:70,color:'#7f1d1d',lineWidth:1,lineStyle:2});charts.rsi.createPriceLine({price:30,color:'#14532d',lineWidth:1,lineStyle:2});
  let lock=false;[['p',['r','m']],['r',['p','m']],['m',['p','r']]].forEach(([a,o])=>charts[a].timeScale().subscribeVisibleLogicalRangeChange(rg=>{
    if(lock||!rg)return;lock=true;o.forEach(k=>charts[k].timeScale().setVisibleLogicalRange(rg));lock=false}));
}
let CS=[];
async function loadChart(){
  initCharts();const tf=$('#tfSel').value,d=await api('/api/candles?tf='+tf+'&limit=300');if(!d.length)return;
  const ln=k=>d.filter(x=>x[k]!=null).map(x=>({time:x.time,value:x[k]}));
  charts.candle.setData(d.map(x=>({time:x.time,open:x.open,high:x.high,low:x.low,close:x.close})));
  charts.e20.setData(ln('ema20'));charts.e50.setData(ln('ema50'));charts.e200.setData(ln('ema200'));charts.rsi.setData(ln('rsi'));
  charts.macd.setData(ln('macd'));charts.sig.setData(ln('macd_sig'));
  charts.hist.setData(d.filter(x=>x.macd_hist!=null).map(x=>({time:x.time,value:x.macd_hist,color:x.macd_hist>=0?'#166534':'#7f1d1d'})));
  CS=await api('/api/signals?limit=50');await refreshChartLines();
}
async function refreshChartLines(){
  if(!charts)return;const tf=$('#tfSel').value;
  charts.lines.forEach(l=>charts.candle.removePriceLine(l));charts.lines=[];
  const add=(price,color,title,style=0)=>charts.lines.push(charts.candle.createPriceLine({price,color,lineWidth:1,lineStyle:style,axisLabelVisible:true,title}));
  const open=CS.find(s=>s.status==='OPEN');
  if(open){add(open.entry,'#e5e7eb','Entry');add(open.sl_now||open.sl,'#ef4444','SL');add(open.tp1,'#22c55e','TP1');add(open.tp2,'#22c55e','TP2');add(open.tp3,'#22c55e','TP3')}
  if($('#sr').checked){try{(await api('/api/levels?tf='+tf)).forEach(l=>add(l.price,'#475569','S/R×'+l.touches,2))}catch(e){}}
  const sec=SEC[tf];charts.candle.setMarkers(CS.filter(s=>s.tf===tf).map(s=>({time:Math.floor(s.ts/sec)*sec-sec,position:s.side==='BUY'?'belowBar':'aboveBar',
    color:s.side==='BUY'?'#22c55e':'#ef4444',shape:s.side==='BUY'?'arrowUp':'arrowDown',text:s.side+' '+s.score})).sort((a,b)=>a.time-b.time));
}
$('#tfSel').onchange=loadChart;$('#sr').onchange=refreshChartLines;
setInterval(()=>{if(VIEW==='chart')loadChart();if(VIEW==='sig')loadSignals()},10000);
window.addEventListener('resize',()=>{if(charts)['p','r','m'].forEach((k,i)=>charts[k].applyOptions({width:[$('#chP'),$('#chR'),$('#chM')][i].clientWidth}))});
if('serviceWorker' in navigator)navigator.serviceWorker.register('/sw.js');
tick();setInterval(tick,2000);
