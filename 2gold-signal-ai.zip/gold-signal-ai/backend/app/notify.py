import httpx
from . import config

def send(text):
    if not config.TELEGRAM_TOKEN or not config.TELEGRAM_CHAT_ID: return False
    try:
        r = httpx.post(f"https://api.telegram.org/bot{config.TELEGRAM_TOKEN}/sendMessage",
                       json={"chat_id": config.TELEGRAM_CHAT_ID, "text": text, "parse_mode": "HTML"}, timeout=8)
        return r.status_code == 200
    except Exception:
        return False

def fmt_signal(s, mins):
    e = "🟢" if s["side"] == "BUY" else "🔴"
    return (f"{e} <b>{s['side']} XAUUSD</b> ({s['tf']})  Điểm: <b>{s['score']}/100</b>\n"
            f"Entry: <b>{s['entry']}</b>\nSL: {s['sl']}\nTP1: {s['tp1']} | TP2: {s['tp2']} | TP3: {s['tp3']}\n"
            f"R:R (TP2): 1:{s['rr']}\nLot gợi ý: {s['lot']} (rủi ro ≈ ${s['loss_if_sl']})\n"
            f"Hết hiệu lực sau {mins} phút\n\n<i>Lý do:</i> " + "; ".join(s["reasons"]) +
            "\n\n⚠️ Không phải lời khuyên đầu tư. Luôn đặt SL.")
