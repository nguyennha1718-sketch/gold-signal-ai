"""Lay gia thuc tu API cong khai cua Binance (khong can khoa), tu chay ngam trong backend.
Nguon: PAXGUSDT. LUU Y: PAXG la token vang, khong phai spot XAUUSD cua Exness."""
import time, httpx
from . import config

BASE = "https://data-api.binance.vision"
STATUS = {"err": None}
IV = {"M1": "1m", "M5": "5m", "M15": "15m", "M30": "30m", "H1": "1h"}

def klines(tf, limit):
    r = httpx.get(f"{BASE}/api/v3/klines", timeout=10,
                  params={"symbol": config.BINANCE_SYMBOL, "interval": IV[tf], "limit": limit})
    r.raise_for_status()
    now_ms = int(time.time() * 1000)
    return [{"t": k[0] // 1000, "o": float(k[1]), "h": float(k[2]), "l": float(k[3]),
             "c": float(k[4]), "v": float(k[5])} for k in r.json() if k[6] < now_ms]   # bo nen dang chay

def book():
    r = httpx.get(f"{BASE}/api/v3/ticker/bookTicker", params={"symbol": config.BINANCE_SYMBOL}, timeout=5)
    r.raise_for_status(); j = r.json()
    return float(j["bidPrice"]), float(j["askPrice"])

def run(push):
    done, tries = {}, {}
    while True:
        try:
            now = int(time.time()); payload, candles = {}, {}
            for tf, sec in config.TF_SECONDS.items():
                b = now // sec
                if done.get(tf) == b or now % sec < 1: continue
                first = tf not in done
                rows = klines(tf, 1000 if first else 3)
                tries[tf] = tries.get(tf, 0) + 1
                if rows and (first or rows[-1]["t"] == (b - 1) * sec or tries[tf] >= 3):
                    candles[tf] = rows; done[tf] = b; tries[tf] = 0
            bid, ask = book()
            payload["tick"] = {"bid": bid, "ask": ask}
            if candles: payload["candles"] = candles
            push(payload); STATUS["err"] = None
        except Exception as e:
            STATUS["err"] = str(e)[:160]; print("feeder loi:", e)
        time.sleep(1)
