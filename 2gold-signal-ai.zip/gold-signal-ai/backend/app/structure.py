"""Price action: swing, ho tro/khang cu, FVG, Order Block, Liquidity Sweep, Fibonacci.
Moi ham chi dung du lieu DA DONG (khong nhin tuong lai)."""
import numpy as np
import pandas as pd

def swings(df, left=3, right=3):
    h, l = df.high.values, df.low.values
    sh, sl = [], []
    for i in range(left, len(df) - right):
        if h[i] == h[i-left:i+right+1].max(): sh.append((i, h[i]))
        if l[i] == l[i-left:i+right+1].min(): sl.append((i, l[i]))
    return sh, sl

def sr_levels(df, atr_val, lookback=150):
    d = df.iloc[-lookback:]
    sh, sl = swings(d)
    pts = sorted([p for _, p in sh] + [p for _, p in sl])
    zones, tol = [], atr_val * 0.5
    for p in pts:
        if zones and abs(p - np.mean(zones[-1])) <= tol: zones[-1].append(p)
        else: zones.append([p])
    return [(float(np.mean(z)), len(z)) for z in zones if len(z) >= 2]

def fvg(df, lookback=30):
    out, n = [], len(df)
    for i in range(max(2, n - lookback), n):
        a, c = df.iloc[i-2], df.iloc[i]
        if c.low > a.high: gap = (a.high, c.low, "bull")
        elif c.high < a.low: gap = (c.high, a.low, "bear")
        else: continue
        later = df.iloc[i+1:]
        if gap[2] == "bull" and len(later) and later.low.min() <= gap[0]: continue
        if gap[2] == "bear" and len(later) and later.high.max() >= gap[1]: continue
        out.append((gap[2], float(gap[0]), float(gap[1]), i))
    return out

def order_blocks(df, atr_val, lookback=40):
    out, n = [], len(df)
    for i in range(max(1, n - lookback), n - 3):
        move = df.close.iloc[i+3] - df.close.iloc[i]
        c = df.iloc[i]
        if move > 1.5 * atr_val and c.close < c.open:
            out.append(("bull", float(c.low), float(c.high), i))
        elif move < -1.5 * atr_val and c.close > c.open:
            out.append(("bear", float(c.low), float(c.high), i))
    return out

def liquidity_sweep(df, lookback=20):
    if len(df) < lookback + 2: return None
    last = df.iloc[-1]; ref = df.iloc[-lookback-1:-1]
    if last.low < ref.low.min() and last.close > ref.low.min() and last.close > last.open: return "bull"
    if last.high > ref.high.max() and last.close < ref.high.max() and last.close < last.open: return "bear"
    return None

def fib(df, lookback=60):
    d = df.iloc[-lookback:]
    hi, lo = d.high.max(), d.low.min()
    up = d.high.values.argmax() > d.low.values.argmin()
    rng = hi - lo
    return {"dir": "up" if up else "down",
            "levels": {r: float(hi - rng*r if up else lo + rng*r) for r in (0.382, 0.5, 0.618)}}

def breakout_retest(df, levels, atr_val):
    if len(df) < 12: return None
    last = df.iloc[-1]; seg = df.iloc[-9:-1]
    for lvl, _ in levels:
        if seg.close.iloc[0] < lvl < seg.close.max() and abs(last.low - lvl) < 0.4*atr_val \
           and last.close > lvl and last.close > last.open: return "bull"
        if seg.close.iloc[0] > lvl > seg.close.min() and abs(last.high - lvl) < 0.4*atr_val \
           and last.close < lvl and last.close < last.open: return "bear"
    return None
