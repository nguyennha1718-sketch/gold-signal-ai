import math

def position_size(balance, risk_pct, sl_dist, contract_size=100.0, lot_step=0.01, min_lot=0.01):
    """Lot = tien rui ro / (khoang SL * contract). Lam tron XUONG de khong vuot rui ro."""
    risk_usd = balance * risk_pct / 100
    if sl_dist <= 0: return {"lot": 0, "risk_usd": 0, "loss_if_sl": 0, "warning": "SL khong hop le"}
    raw = risk_usd / (sl_dist * contract_size)
    lot = math.floor(raw / lot_step) * lot_step
    warn = None
    if lot < min_lot:
        lot = 0.0
        warn = "Von qua nho: lot toi thieu van vuot muc rui ro. KHONG vao lenh."
    loss = round(lot * sl_dist * contract_size, 2)
    return {"lot": round(lot, 2), "risk_usd": round(risk_usd, 2), "loss_if_sl": loss, "warning": warn}
