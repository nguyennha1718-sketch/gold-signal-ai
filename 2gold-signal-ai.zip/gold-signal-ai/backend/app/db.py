import json, time
from sqlalchemy import create_engine, Column, String, Float, Integer, Text, Boolean
from sqlalchemy.orm import declarative_base, sessionmaker
from . import config

Base = declarative_base()
engine = create_engine(config.DATABASE_URL, pool_pre_ping=True,
                       connect_args={"check_same_thread": False} if config.DATABASE_URL.startswith("sqlite") else {})
Session = sessionmaker(bind=engine, expire_on_commit=False)

class SignalRow(Base):
    __tablename__ = "signals"
    id = Column(Integer, primary_key=True, autoincrement=True)
    ts = Column(Integer, index=True)
    valid_until = Column(Integer)
    tf = Column(String(4)); side = Column(String(4))
    entry = Column(Float); sl = Column(Float)
    tp1 = Column(Float); tp2 = Column(Float); tp3 = Column(Float)
    rr = Column(Float); score = Column(Integer)
    lot = Column(Float); risk_usd = Column(Float)
    reasons = Column(Text)
    status = Column(String(8), default="OPEN")      # OPEN / CLOSED
    stage = Column(Integer, default=0)
    outcome = Column(String(12)); r_result = Column(Float); closed_ts = Column(Integer)
    sl_now = Column(Float)

    def to_dict(self):
        d = {c.name: getattr(self, c.name) for c in self.__table__.columns}
        d["reasons"] = json.loads(self.reasons or "[]")
        return d

class SettingRow(Base):
    __tablename__ = "settings"
    key = Column(String(40), primary_key=True)
    value = Column(Text)

def init():
    for i in range(30):          # cho Postgres khoi dong xong
        try:
            Base.metadata.create_all(engine); return
        except Exception as e:
            print("DB chua san sang:", e); time.sleep(2)
    raise RuntimeError("Khong ket noi duoc database")

def load_settings():
    cfg = dict(config.DEFAULTS)
    with Session() as s:
        for r in s.query(SettingRow).all():
            cfg[r.key] = json.loads(r.value)
    return cfg

def save_settings(upd):
    with Session() as s:
        for k, v in upd.items():
            if k in config.DEFAULTS:
                s.merge(SettingRow(key=k, value=json.dumps(v)))
        s.commit()
