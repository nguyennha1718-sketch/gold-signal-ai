import numpy as np

def summarize(rs):
    """rs: list R cua cac lenh da dong (da tru chi phi)."""
    n = len(rs)
    if n == 0:
        return {"trades": 0, "wins": 0, "losses": 0, "win_rate": None, "profit_factor": None,
                "avg_rr": None, "expectancy_r": None, "max_drawdown_r": 0.0, "total_r": 0.0}
    a = np.array(rs, dtype=float)
    wins, losses = a[a > 0], a[a <= 0]
    gp, gl = wins.sum(), -losses.sum()
    eq = np.cumsum(a); peak = np.maximum.accumulate(np.concatenate([[0], eq]))[1:]
    return {
        "trades": n, "wins": int(len(wins)), "losses": int(len(losses)),
        "win_rate": round(100 * len(wins) / n, 1),
        "profit_factor": round(gp / gl, 2) if gl > 0 else None,
        "avg_rr": round(wins.mean() / -losses.mean(), 2) if len(wins) and len(losses) and losses.mean() < 0 else None,
        "expectancy_r": round(a.mean(), 3),
        "max_drawdown_r": round(float((peak - eq).max()), 2),
        "total_r": round(float(a.sum()), 2),
    }
