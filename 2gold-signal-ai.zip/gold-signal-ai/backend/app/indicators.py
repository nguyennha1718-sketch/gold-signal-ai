import numpy as np
import pandas as pd

def ema(s, n): return s.ewm(span=n, adjust=False).mean()

def rsi(c, n=14):
    d = c.diff()
    up = d.clip(lower=0).ewm(alpha=1/n, adjust=False).mean()
    dn = (-d.clip(upper=0)).ewm(alpha=1/n, adjust=False).mean()
    rs = up / dn.replace(0, np.nan)
    return (100 - 100 / (1 + rs)).fillna(50)

def macd(c, f=12, s=26, sg=9):
    m = ema(c, f) - ema(c, s)
    sig = ema(m, sg)
    return m, sig, m - sig

def bollinger(c, n=20, k=2):
    mid = c.rolling(n).mean(); sd = c.rolling(n).std()
    return mid + k*sd, mid, mid - k*sd

def atr(df, n=14):
    pc = df.close.shift()
    tr = pd.concat([df.high-df.low, (df.high-pc).abs(), (df.low-pc).abs()], axis=1).max(axis=1)
    return tr.ewm(alpha=1/n, adjust=False).mean()

def adx(df, n=14):
    up = df.high.diff(); dn = -df.low.diff()
    pdm = np.where((up > dn) & (up > 0), up, 0.0)
    mdm = np.where((dn > up) & (dn > 0), dn, 0.0)
    a = atr(df, n)
    pdi = 100 * pd.Series(pdm, index=df.index).ewm(alpha=1/n, adjust=False).mean() / a
    mdi = 100 * pd.Series(mdm, index=df.index).ewm(alpha=1/n, adjust=False).mean() / a
    dx = 100 * (pdi - mdi).abs() / (pdi + mdi).replace(0, np.nan)
    return dx.ewm(alpha=1/n, adjust=False).mean().fillna(0), pdi, mdi

def vwap(df):
    """VWAP theo ngay (dung tick volume cua MT5)."""
    if "volume" not in df or df.volume.sum() == 0:
        return pd.Series(np.nan, index=df.index)
    tp = (df.high + df.low + df.close) / 3
    day = df.index.floor("D")
    return (tp * df.volume).groupby(day).cumsum() / df.volume.groupby(day).cumsum()

def add_all(df):
    df = df.copy()
    for n in (9, 20, 50, 200): df[f"ema{n}"] = ema(df.close, n)
    df["rsi"] = rsi(df.close)
    df["macd"], df["macd_sig"], df["macd_hist"] = macd(df.close)
    df["bb_up"], df["bb_mid"], df["bb_lo"] = bollinger(df.close)
    df["atr"] = atr(df)
    df["adx"], df["pdi"], df["mdi"] = adx(df)
    df["vwap"] = vwap(df)
    return df
