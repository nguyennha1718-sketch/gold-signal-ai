"""Engine tin hieu da khung thoi gian. Hoan toan nhan qua: chi dung nen DA DONG."""
import numpy as np
from . import structure as st
from .risk import position_size

MIN_ROWS = 210

def _trend(df):
    r = df.iloc[-1]
    if r.ema20 > r.ema50 and r.close > r.ema50 and (r.ema50 > r.ema200 or r.close > r.ema200): return 1
    if r.ema20 < r.ema50 and r.close < r.ema50 and (r.ema50 < r.ema200 or r.close < r.ema200): return -1
    return 0

def trends(frames):
    return {tf: (_trend(df) if len(df) >= MIN_ROWS else 0) for tf, df in frames.items()}

def _wait(reason, tr, extra=None):
    d = {"decision": "WAIT", "label": "WAIT – KHÔNG GIAO DỊCH", "reason": reason, "trend": tr, "signal": None}
    if extra: d.update(extra)
    return d

def analyze(frames, cfg, live_price=None):
    tf = cfg["entry_tf"]
    need = {tf, "H1", "M15"}
    for k in need:
        if k not in frames or len(frames[k]) < MIN_ROWS:
            return _wait(f"Chưa đủ dữ liệu {k} (cần ≥{MIN_ROWS} nến đã đóng)", {})
    tr = trends(frames)
    df = frames[tf]; last = df.iloc[-1]; a = float(last.atr)
    if not np.isfinite(a) or a <= 0: return _wait("ATR chưa sẵn sàng", tr)

    # Bien dong bat thuong
    med = float(df.atr.iloc[-100:].median())
    if a > 2.5 * med or (last.high - last.low) > 3.5 * med:
        return _wait("Thị trường biến động bất thường (ATR tăng vọt) – đứng ngoài", tr, {"warning": "volatility"})

    # Huong: H1 va M15 phai dong thuan (khung lon hon entry thi chi can H1)
    gates = ["H1"] if tf in ("M15", "M30", "H1") else ["M15", "H1"]
    dirs = {tr[g] for g in gates}
    if len(dirs) != 1 or 0 in dirs:
        return _wait("Xu hướng khung lớn không đồng thuận / không rõ", tr)
    side = dirs.pop()
    name = "BUY" if side == 1 else "SELL"
    score, why = 0, []

    score += 24
    why.append(f"H1{' & M15' if 'M15' in gates else ''} cùng xu hướng {'tăng' if side==1 else 'giảm'}")
    if tr.get("M30") == side: score += 6; why.append("M30 đồng thuận")
    if side == 1 and last.ema9 > last.ema20 > last.ema50 or side == -1 and last.ema9 < last.ema20 < last.ema50:
        score += 10; why.append(f"{tf}: EMA 9/20/50 xếp đúng chiều")
    if last.adx >= 25: score += 10; why.append(f"ADX {last.adx:.0f} (xu hướng mạnh)")
    elif last.adx >= 20: score += 5; why.append(f"ADX {last.adx:.0f} (vừa)")
    else: return _wait(f"ADX {last.adx:.0f} < 20: thị trường đi ngang", tr)
    if (side == 1 and 40 <= last.rsi <= 68) or (side == -1 and 32 <= last.rsi <= 60):
        score += 5; why.append(f"RSI {last.rsi:.0f} còn dư địa")
    elif (side == 1 and last.rsi > 75) or (side == -1 and last.rsi < 25):
        return _wait(f"RSI {last.rsi:.0f} quá cực đoan – tránh đuổi giá", tr)
    prev = df.iloc[-2]
    if side * last.macd_hist > 0 and side * (last.macd_hist - prev.macd_hist) > 0:
        score += 5; why.append("MACD histogram ủng hộ")
    if abs(last.close - last.ema20) < 1.0 * a: score += 5; why.append("Giá gần EMA20 (hồi về)")

    # Cau truc
    levels = st.sr_levels(df, a)
    trig, s = [], 0
    sw = st.liquidity_sweep(df)
    if sw == ("bull" if side == 1 else "bear"): s += 15; trig.append("Liquidity Sweep")
    br = st.breakout_retest(df, levels, a)
    if br == ("bull" if side == 1 else "bear"): s += 15; trig.append("Breakout + Retest")
    want = "bull" if side == 1 else "bear"
    for kind, lo, hi, _ in st.fvg(df):
        if kind == want and last.low <= hi and last.close >= lo: s += 10; trig.append("Giá trong FVG"); break
    for kind, lo, hi, _ in st.order_blocks(df, a):
        if kind == want and last.low <= hi and last.close >= lo: s += 10; trig.append("Giá tại Order Block"); break
    fb = st.fib(df)
    if fb["dir"] == ("up" if side == 1 else "down"):
        lv = fb["levels"]; lo_, hi_ = sorted([lv[0.5], lv[0.618]])
        if lo_ - 0.3*a <= last.close <= hi_ + 0.3*a: s += 5; trig.append("Fib 0.5–0.618")
    if not any(t in trig for t in ("Liquidity Sweep", "Breakout + Retest", "Giá trong FVG", "Giá tại Order Block")):
        return _wait("Chưa có điểm kích hoạt price action (sweep/retest/FVG/OB)", tr)
    score += min(s, 35); why += trig

    # SL / TP
    entry = float(live_price if live_price is not None else last.close)
    recent = df.iloc[-10:]
    if side == 1: sl = min(recent.low.min(), last.low) - 0.25 * a
    else: sl = max(recent.high.max(), last.high) + 0.25 * a
    dist = abs(entry - sl)
    if dist < 1.0 * a:
        sl = entry - side * 1.0 * a; dist = 1.0 * a
    dist += cfg["spread_usd"]
    if dist > cfg["max_sl_usd"]:
        return _wait(f"SL quá rộng ({dist:.2f}$ > {cfg['max_sl_usd']}$)", tr, {"warning": "sl_wide"})
    tps = [entry + side * dist * k for k in (1, 2, 3)]
    rr = round(abs(tps[1] - entry) / dist, 2)
    if rr < cfg["min_rr"]:
        return _wait(f"R:R {rr} < tối thiểu {cfg['min_rr']}", tr)
    for lvl, n in levels:   # can S/R gan ngay truoc TP1
        if side * (lvl - entry) > 0 and side * (lvl - entry) < 1.0 * dist and n >= 2:
            return _wait(f"Vùng S/R {lvl:.2f} chắn ngay trước TP1", tr)
    if score < cfg["min_score"]:
        return _wait(f"Điểm {score} < ngưỡng {cfg['min_score']}", tr, {"score": score})

    size = position_size(cfg["balance"], cfg["risk_pct"], dist, cfg["contract_size"])
    if size["lot"] <= 0:
        return _wait(size["warning"], tr)
    return {
        "decision": name, "label": name, "trend": tr, "reason": "; ".join(why),
        "signal": {"side": name, "tf": tf, "entry": round(entry, 2), "sl": round(sl, 2),
                   "tp1": round(tps[0], 2), "tp2": round(tps[1], 2), "tp3": round(tps[2], 2),
                   "rr": rr, "score": int(min(score, 100)), "reasons": why,
                   "sl_dist": round(dist, 2), **size},
    }
