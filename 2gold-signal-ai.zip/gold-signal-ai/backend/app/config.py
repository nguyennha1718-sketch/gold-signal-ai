import os

def env(k, d=None):
    return os.environ.get(k, d)

DATABASE_URL = env("DATABASE_URL", "sqlite:///./gold.db")
BRIDGE_API_KEY = env("BRIDGE_API_KEY", "")          # khoa bi mat giua VPS MT5 va backend
APP_PASSWORD = env("APP_PASSWORD", "")               # mat khau vao app
TELEGRAM_TOKEN = env("TELEGRAM_TOKEN", "")
TELEGRAM_CHAT_ID = env("TELEGRAM_CHAT_ID", "")

SYMBOL = "XAUUSD"
TIMEFRAMES = ["M1", "M5", "M15", "M30", "H1"]
TF_SECONDS = {"M1": 60, "M5": 300, "M15": 900, "M30": 1800, "H1": 3600}
STALE_SECONDS = 15           # gia cu hon muc nay = du lieu tre

# Cai dat mac dinh (co the doi trong Settings)
DEFAULTS = {
    "entry_tf": "M5",
    "risk_pct": 0.75,         # 0.5 - 1%
    "balance": 1000.0,
    "min_score": 70,
    "min_rr": 2.0,
    "max_signals_per_day": 6,
    "max_sl_usd": 8.0,        # SL toi da tinh theo gia (USD/oz)
    "signal_ttl_min": 15,
    "spread_usd": 0.20,       # chi phi gia dinh cho backtest/RR
    "telegram": True,
    "contract_size": 100.0,   # 1 lot XAUUSD = 100 oz (kiem tra voi Exness)
}

DATA_SOURCE = env("DATA_SOURCE", "binance")          # binance | bridge (MT5)
BINANCE_SYMBOL = env("BINANCE_SYMBOL", "PAXGUSDT")   # token vang PAXG ~ 1 oz vang
SOURCE_NOTE = {"binance": "Binance PAXGUSDT (token vàng, KHÔNG phải spot XAUUSD – giá có thể lệch)",
               "bridge": "MetaTrader 5 (Exness)"}.get(DATA_SOURCE, DATA_SOURCE)
