import json, time, threading, hmac
from datetime import datetime, timezone
import pandas as pd
from fastapi import FastAPI, Header, HTTPException, Body, Query
from . import config, db, engine as eng, indicators as ind, metrics, notify
from .trade import Trade

app = FastAPI(title="GOLD SIGNAL AI")
FAILS = {}

def _feeder_err():
    if config.DATA_SOURCE != "binance": return None
    from . import feeder
    return feeder.STATUS["err"]

from fastapi.responses import JSONResponse

@app.middleware("http")
async def limiter(request, call_next):
    """Chan do mat khau: 10 lan sai / IP -> khoa 15 phut."""
    ip = (request.headers.get("x-forwarded-for") or (request.client.host if request.client else "?")).split(",")[0].strip()
    n, t0 = FAILS.get(ip, (0, 0))
    if n >= 10 and time.time() - t0 < 900:
        return JSONResponse({"detail": "Sai quá nhiều lần, thử lại sau 15 phút"}, status_code=429)
    resp = await call_next(request)
    if resp.status_code == 401:
        FAILS[ip] = ((n + 1) if time.time() - t0 < 900 else 1, time.time())
    elif resp.status_code == 200 and request.url.path.startswith("/api/"):
        FAILS.pop(ip, None)
    return resp
LOCK = threading.RLock()
RAW = {tf: pd.DataFrame() for tf in config.TIMEFRAMES}     # nen da dong
FR = {}                                                    # nen + chi bao
TICK = {"bid": None, "ask": None, "t": 0}
LAST = {"decision": None, "ts": 0}
TRADES = {}                                                # id -> Trade (dang mo)
FLAGS = {"stale_alerted": False}
CFG = {}

def now(): return int(time.time())

def auth(pw):
    if not config.APP_PASSWORD or not hmac.compare_digest(pw or "", config.APP_PASSWORD):
        raise HTTPException(401, "Sai mật khẩu")

@app.on_event("startup")
def startup():
    db.init(); CFG.update(db.load_settings())
    with db.Session() as s:     # khoi phuc lenh dang mo
        for r in s.query(db.SignalRow).filter_by(status="OPEN").all():
            t = Trade(r.side, r.entry, r.sl, [r.tp1, r.tp2, r.tp3],
                      CFG["spread_usd"] + 0.0)
            t.stage = r.stage or 0
            if t.stage >= 1: t.sl = r.entry
            TRADES[r.id] = t
    threading.Thread(target=watchdog, daemon=True).start()
    if config.DATA_SOURCE == "binance":
        from . import feeder
        threading.Thread(target=feeder.run, args=(process,), daemon=True).start()

def ingest_candles(tf, rows):
    df = pd.DataFrame(rows).rename(columns={"t": "time", "o": "open", "h": "high", "l": "low", "c": "close", "v": "volume"})
    df["time"] = pd.to_datetime(df["time"], unit="s", utc=True)
    df = df.set_index("time")[["open", "high", "low", "close", "volume"]].astype(float)
    old = RAW[tf]
    RAW[tf] = pd.concat([old, df])[lambda x: ~x.index.duplicated(keep="last")].sort_index().iloc[-1500:]
    FR[tf] = ind.add_all(RAW[tf])

def track(price_bid, price_ask):
    with db.Session() as s:
        for sid, t in list(TRADES.items()):
            p = price_bid if t.side == 1 else price_ask
            ev = t.update(p, p)
            if not ev: continue
            row = s.get(db.SignalRow, sid)
            row.stage, row.sl_now = t.stage, t.sl
            for e in ev:
                notify.send(f"📌 Lệnh #{sid} {row.side}: <b>{e}</b> @ {p:.2f}") if CFG.get("telegram") else None
            if t.closed:
                row.status, row.outcome, row.r_result, row.closed_ts = "CLOSED", t.outcome, round(t.final_r, 3), now()
                del TRADES[sid]
            s.commit()

def maybe_signal():
    tf = CFG["entry_tf"]
    if tf not in FR or len(FR[tf]) == 0: return
    bar_ts = int(FR[tf].index[-1].timestamp())
    if LAST["ts"] == bar_ts: return           # moi nen dong chi phan tich 1 lan
    LAST["ts"] = bar_ts
    px = TICK["ask"] if TICK["ask"] else None
    res = eng.analyze(FR, CFG)
    LAST["decision"] = {**res, "bar_ts": bar_ts}
    sg = res.get("signal")
    if not sg: return
    if TICK["bid"] is None or now() - TICK["t"] > config.STALE_SECONDS: return   # khong phat tin hieu khi du lieu tre
    with db.Session() as s:
        day0 = int(datetime.now(timezone.utc).replace(hour=0, minute=0, second=0, microsecond=0).timestamp())
        today = s.query(db.SignalRow).filter(db.SignalRow.ts >= day0).count()
        if today >= CFG["max_signals_per_day"]:
            LAST["decision"]["reason"] = "Đã đạt giới hạn tín hiệu trong ngày"; LAST["decision"]["decision"] = "WAIT"; return
        if TRADES:
            LAST["decision"]["reason"] = "Đang có lệnh mở – không phát thêm"; LAST["decision"]["decision"] = "WAIT"; return
        last = s.query(db.SignalRow).order_by(db.SignalRow.ts.desc()).first()
        if last and now() - last.ts < 3 * config.TF_SECONDS[tf]:
            LAST["decision"]["reason"] = "Hồi chiêu sau tín hiệu trước"; LAST["decision"]["decision"] = "WAIT"; return
        # Lam lai voi gia live thuc te de Entry/SL/TP/lot chinh xac
        live = TICK["ask"] if sg["side"] == "BUY" else TICK["bid"]
        res = eng.analyze(FR, CFG, live_price=live)
        LAST["decision"] = {**res, "bar_ts": bar_ts}
        sg = res.get("signal")
        if not sg: return
        ttl = CFG["signal_ttl_min"]
        row = db.SignalRow(ts=now(), valid_until=now() + ttl * 60, tf=sg["tf"], side=sg["side"], entry=sg["entry"],
                           sl=sg["sl"], tp1=sg["tp1"], tp2=sg["tp2"], tp3=sg["tp3"], rr=sg["rr"], score=sg["score"],
                           lot=sg["lot"], risk_usd=sg["loss_if_sl"], reasons=json.dumps(sg["reasons"], ensure_ascii=False),
                           sl_now=sg["sl"])
        s.add(row); s.commit()
        TRADES[row.id] = Trade(sg["side"], sg["entry"], sg["sl"], [sg["tp1"], sg["tp2"], sg["tp3"]], CFG["spread_usd"])
        if CFG.get("telegram"): notify.send(notify.fmt_signal(sg, ttl))

def watchdog():
    while True:
        time.sleep(5)
        try:
            age = now() - TICK["t"] if TICK["t"] else None
            if age is not None and age > config.STALE_SECONDS and not FLAGS["stale_alerted"]:
                FLAGS["stale_alerted"] = True
                if CFG.get("telegram"): notify.send(f"⚠️ Mất dữ liệu XAUUSD {age}s. Không phát tín hiệu mới.")
            if TICK["t"] and age is not None and age <= config.STALE_SECONDS and FLAGS["stale_alerted"]:
                FLAGS["stale_alerted"] = False
                if CFG.get("telegram"): notify.send("✅ Dữ liệu XAUUSD đã kết nối lại.")
            with db.Session() as s:     # tin hieu het hieu luc (de thong tin; lenh mo van duoc theo doi)
                pass
        except Exception:
            pass

def process(payload):
    with LOCK:
        for tf, rows in (payload.get("candles") or {}).items():
            if tf in RAW and rows: ingest_candles(tf, rows)
        tk = payload.get("tick")
        if tk:
            TICK.update(bid=tk["bid"], ask=tk["ask"], t=now())     # dung gio server de do do tre
            track(tk["bid"], tk["ask"])
        if payload.get("candles"): maybe_signal()

@app.post("/api/ingest")
def ingest(payload: dict = Body(...), x_bridge_key: str = Header(None)):
    if config.DATA_SOURCE != "bridge":
        raise HTTPException(403, "Đang dùng nguồn dữ liệu nội bộ, không nhận bridge")
    if not config.BRIDGE_API_KEY or not hmac.compare_digest(x_bridge_key or "", config.BRIDGE_API_KEY):
        raise HTTPException(401, "Sai bridge key")
    process(payload)
    return {"ok": True}

@app.get("/api/state")
def state(x_app_password: str = Header(None)):
    auth(x_app_password)
    with LOCK:
        age = now() - TICK["t"] if TICK["t"] else None
        stale = age is None or age > config.STALE_SECONDS
        tr = eng.trends(FR) if FR else {}
        d = LAST["decision"] or {"decision": "WAIT", "label": "WAIT – KHÔNG GIAO DỊCH", "reason": "Chưa có dữ liệu"}
        cd = {tf: config.TF_SECONDS[tf] - (now() % config.TF_SECONDS[tf]) for tf in config.TIMEFRAMES}
        with db.Session() as s:
            last = s.query(db.SignalRow).order_by(db.SignalRow.ts.desc()).first()
            last = last.to_dict() if last else None
        return {"price": {"bid": TICK["bid"], "ask": TICK["ask"], "age_s": age}, "stale": stale,
                "connection": "MẤT/TRỄ DỮ LIỆU" if stale else "OK", "trend": tr, "decision": d,
                "countdown": cd, "latest_signal": last, "source": config.SOURCE_NOTE, "feeder_error": _feeder_err(), "entry_tf": CFG["entry_tf"], "open_trades": len(TRADES)}

@app.get("/api/signals")
def signals(limit: int = 50, x_app_password: str = Header(None)):
    auth(x_app_password)
    with db.Session() as s:
        return [r.to_dict() for r in s.query(db.SignalRow).order_by(db.SignalRow.ts.desc()).limit(limit)]

@app.get("/api/performance")
def performance(x_app_password: str = Header(None)):
    auth(x_app_password)
    with db.Session() as s:
        rows = s.query(db.SignalRow).filter_by(status="CLOSED").order_by(db.SignalRow.closed_ts).all()
    out = {"overall": metrics.summarize([r.r_result for r in rows]), "by_tf": {}}
    for tf in config.TIMEFRAMES:
        out["by_tf"][tf] = metrics.summarize([r.r_result for r in rows if r.tf == tf])
    out["note"] = "Số liệu từ tín hiệu live đã đóng. Cần ≥100 lệnh mới có ý nghĩa thống kê."
    return out

@app.get("/api/candles")
def candles(tf: str = "M5", limit: int = 300, x_app_password: str = Header(None)):
    auth(x_app_password)
    with LOCK:
        df = FR.get(tf)
        if df is None: return []
        d = df.iloc[-limit:].reset_index()
        d["time"] = d["time"].map(lambda x: int(x.timestamp()))
        return json.loads(d.round(3).to_json(orient="records"))

@app.get("/api/levels")
def levels(tf: str = "M5", x_app_password: str = Header(None)):
    auth(x_app_password)
    from . import structure as st
    with LOCK:
        df = FR.get(tf)
        if df is None or len(df) < 60: return []
        return [{"price": round(p, 2), "touches": n} for p, n in st.sr_levels(df, float(df.atr.iloc[-1]))]

@app.get("/api/settings")
def get_settings(x_app_password: str = Header(None)):
    auth(x_app_password); return CFG

@app.post("/api/settings")
def set_settings(upd: dict = Body(...), x_app_password: str = Header(None)):
    auth(x_app_password)
    if "risk_pct" in upd: upd["risk_pct"] = min(max(float(upd["risk_pct"]), 0.1), 1.0)   # tran 1%
    if "min_rr" in upd: upd["min_rr"] = max(float(upd["min_rr"]), 1.5)
    if "entry_tf" in upd and upd["entry_tf"] not in config.TIMEFRAMES: raise HTTPException(400, "TF sai")
    db.save_settings(upd); CFG.update({k: v for k, v in upd.items() if k in config.DEFAULTS})
    return CFG

@app.get("/health")
def health(): return {"ok": True}

import os
from fastapi.staticfiles import StaticFiles
_static = os.path.join(os.path.dirname(__file__), "..", "static")
if os.path.isdir(_static):
    app.mount("/", StaticFiles(directory=_static, html=True), name="static")
