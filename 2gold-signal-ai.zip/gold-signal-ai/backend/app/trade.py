"""Mo phong 1 lenh: chot 1/3 tai moi TP, sau TP1 doi SL ve hoa von.
Dung chung cho theo doi realtime va backtest -> cung logic.
Neu 1 nen cham ca SL va TP: tinh SL truoc (bao thu)."""

class Trade:
    def __init__(self, side, entry, sl, tps, cost=0.0):
        self.side = 1 if side == "BUY" else -1
        self.entry, self.sl, self.tps = entry, sl, list(tps)
        self.risk = abs(entry - sl)
        self.stage, self.r, self.closed, self.outcome = 0, 0.0, False, None
        self.cost_r = cost / self.risk if self.risk else 0.0

    def _r(self, price):
        return self.side * (price - self.entry) / self.risk

    def _close(self, outcome):
        self.closed, self.outcome = True, outcome

    def update(self, low, high):
        """Tra ve danh sach su kien: 'TP1','TP2','TP3','SL','BE'."""
        ev = []
        if self.closed: return ev
        hit_sl = low <= self.sl if self.side == 1 else high >= self.sl
        if hit_sl:
            remaining = (3 - self.stage) / 3
            self.r += remaining * self._r(self.sl)
            ev.append("SL" if self.stage == 0 else "BE")
            self._close("SL" if self.stage == 0 else f"TP{self.stage}+BE")
            return ev
        while self.stage < 3:
            tp = self.tps[self.stage]
            hit = high >= tp if self.side == 1 else low <= tp
            if not hit: break
            self.r += self._r(tp) / 3
            self.stage += 1
            ev.append(f"TP{self.stage}")
            if self.stage == 1: self.sl = self.entry
        if self.stage == 3: self._close("TP3")
        return ev

    @property
    def final_r(self):
        """R sau khi tru chi phi (spread + commission + truot gia), chi hop le khi da dong."""
        return self.r - self.cost_r
