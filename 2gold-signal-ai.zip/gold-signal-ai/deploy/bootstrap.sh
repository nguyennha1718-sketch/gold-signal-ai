#!/bin/bash
# Dan toan bo noi dung nay vao o "cloud-init script" khi tao may chu Oracle. CHI SUA 6 DONG DUOI.
ZIP_URL="https://github.com/TENGITHUB/gold-signal/raw/main/gold-signal-ai.zip"
DOMAIN="tencuaban.duckdns.org"
DUCK_TOKEN="token-duckdns"
APP_PASSWORD="mat-khau-vao-app-dai-va-kho-doan"
TELEGRAM_TOKEN=""
TELEGRAM_CHAT_ID=""
# ------------------------------------------------------------------
exec > /var/log/gold-bootstrap.log 2>&1
set -x
SUB="${DOMAIN%.duckdns.org}"

# 1) RAM ao 2GB (an toan khi may nho)
if [ ! -f /swapfile ]; then fallocate -l 2G /swapfile && chmod 600 /swapfile && mkswap /swapfile && swapon /swapfile && echo '/swapfile none swap sw 0 0' >> /etc/fstab; fi

# 2) Mo cong 80/443 trong tuong lua cua may
iptables -I INPUT -p tcp -m multiport --dports 80,443 -j ACCEPT
command -v netfilter-persistent >/dev/null && netfilter-persistent save

# 3) DuckDNS: tu cap nhat IP (khong can biet IP)
curl -s "https://www.duckdns.org/update?domains=${SUB}&token=${DUCK_TOKEN}&ip="
echo "*/5 * * * * root curl -s 'https://www.duckdns.org/update?domains=${SUB}&token=${DUCK_TOKEN}&ip=' >/dev/null" > /etc/cron.d/duckdns

# 4) Docker
apt-get update -y && apt-get install -y unzip curl
curl -fsSL https://get.docker.com | sh
systemctl enable --now docker

# 5) Tai ma nguon
mkdir -p /opt/gold && cd /opt/gold
curl -fsSL -o app.zip "$ZIP_URL" && unzip -o app.zip && cd gold-signal-ai

# 6) Tao file cau hinh (khoa ngau nhien)
cat > .env <<ENVEOF
DB_PASSWORD=$(openssl rand -hex 16)
BRIDGE_API_KEY=$(openssl rand -hex 24)
APP_PASSWORD=${APP_PASSWORD}
TELEGRAM_TOKEN=${TELEGRAM_TOKEN}
TELEGRAM_CHAT_ID=${TELEGRAM_CHAT_ID}
DOMAIN=${DOMAIN}
DATA_SOURCE=binance
ENVEOF
chmod 600 .env

# 7) Chay
docker compose up -d --build
echo "XONG: $(date)"
