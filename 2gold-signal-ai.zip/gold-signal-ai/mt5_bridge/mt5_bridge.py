"""Chay tren VPS WINDOWS cung MT5 (da dang nhap tai khoan Exness).
Doc gia that tu MT5 va day len backend qua HTTPS. Mat khau MT5 KHONG roi khoi may nay.
Cai dat: pip install MetaTrader5 requests"""
import os, time, requests, MetaTrader5 as mt5

API = os.environ["BACKEND_URL"].rstrip("/") + "/api/ingest"   # vd https://gold.example.com
KEY = os.environ["BRIDGE_API_KEY"]
SYMBOL = os.environ.get("MT5_SYMBOL", "XAUUSD")              # Exness co the la XAUUSDm / XAUUSDz -> kiem tra
OFFSET_H = float(os.environ.get("SERVER_UTC_OFFSET_HOURS", "0"))  # gio may chu broker so voi UTC. KIEM TRA!
TFS = {"M1": mt5.TIMEFRAME_M1, "M5": mt5.TIMEFRAME_M5, "M15": mt5.TIMEFRAME_M15,
       "M30": mt5.TIMEFRAME_M30, "H1": mt5.TIMEFRAME_H1}
N_FIRST, last_sent = 1500, {}

def post(payload):
    try:
        requests.post(API, json=payload, headers={"X-Bridge-Key": KEY}, timeout=8).raise_for_status()
    except Exception as e:
        print("POST loi:", e)

def closed_candles(tf, n):
    r = mt5.copy_rates_from_pos(SYMBOL, TFS[tf], 1, n)     # vi tri 1 = bo qua nen dang chay
    if r is None: return []
    return [{"t": int(x["time"] - OFFSET_H * 3600), "o": float(x["open"]), "h": float(x["high"]),
             "l": float(x["low"]), "c": float(x["close"]), "v": float(x["tick_volume"])} for x in r]

if not mt5.initialize(): raise SystemExit(f"MT5 init loi: {mt5.last_error()}")
mt5.symbol_select(SYMBOL, True)
while True:
    try:
        candles = {}
        for tf in TFS:
            n = N_FIRST if tf not in last_sent else 3
            rows = closed_candles(tf, n)
            if rows and rows[-1]["t"] != last_sent.get(tf):
                candles[tf] = rows; last_sent[tf] = rows[-1]["t"]
        t = mt5.symbol_info_tick(SYMBOL)
        payload = {"tick": {"bid": t.bid, "ask": t.ask}} if t and t.bid > 0 else {}
        if candles: payload["candles"] = candles
        if payload: post(payload)
    except Exception as e:
        print("Vong loi:", e)
    time.sleep(1)
