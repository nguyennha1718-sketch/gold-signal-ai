"""Xuat du lieu lich su tu MT5 ra CSV de backtest. Chay tren VPS Windows:
python export_history.py 12   (12 thang)"""
import sys, os, MetaTrader5 as mt5, pandas as pd
from datetime import datetime, timedelta, timezone
SYMBOL = os.environ.get("MT5_SYMBOL", "XAUUSD"); OFFSET_H = float(os.environ.get("SERVER_UTC_OFFSET_HOURS", "0"))
months = int(sys.argv[1]) if len(sys.argv) > 1 else 12
TFS = {"M1": mt5.TIMEFRAME_M1, "M5": mt5.TIMEFRAME_M5, "M15": mt5.TIMEFRAME_M15, "M30": mt5.TIMEFRAME_M30, "H1": mt5.TIMEFRAME_H1}
mt5.initialize(); mt5.symbol_select(SYMBOL, True)
end = datetime.now(timezone.utc); start = end - timedelta(days=30 * months)
os.makedirs("data", exist_ok=True)
for tf, c in TFS.items():
    r = mt5.copy_rates_range(SYMBOL, c, start, end)
    if r is None or len(r) == 0: print(tf, "khong co du lieu", mt5.last_error()); continue
    df = pd.DataFrame(r); df["time"] = df["time"] - int(OFFSET_H * 3600)
    df = df.rename(columns={"tick_volume": "volume"})[["time", "open", "high", "low", "close", "volume"]]
    df.to_csv(f"data/{SYMBOL}_{tf}.csv", index=False); print(tf, len(df), "nen")
