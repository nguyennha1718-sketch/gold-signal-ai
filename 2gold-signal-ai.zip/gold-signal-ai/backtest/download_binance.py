"""Tai lich su PAXGUSDT tu Binance ra CSV de backtest (khong can MT5).
python download_binance.py 12   -> ../data/XAUUSD_{TF}.csv"""
import sys, os, time, httpx, pandas as pd
SYM = os.environ.get("BINANCE_SYMBOL", "PAXGUSDT"); months = int(sys.argv[1]) if len(sys.argv) > 1 else 12
IV = {"M1": ("1m", 60), "M5": ("5m", 300), "M15": ("15m", 900), "M30": ("30m", 1800), "H1": ("1h", 3600)}
os.makedirs("../data", exist_ok=True)
end = int(time.time() * 1000); start = end - months * 30 * 86400 * 1000
for tf, (iv, sec) in IV.items():
    rows, cur = [], start
    while cur < end:
        r = httpx.get("https://data-api.binance.vision/api/v3/klines", timeout=20,
                      params={"symbol": SYM, "interval": iv, "startTime": cur, "limit": 1000}); r.raise_for_status()
        k = r.json()
        if not k: break
        rows += [(x[0] // 1000, float(x[1]), float(x[2]), float(x[3]), float(x[4]), float(x[5])) for x in k if x[6] < end]
        cur = k[-1][0] + sec * 1000; time.sleep(0.15)
    pd.DataFrame(rows, columns=["time", "open", "high", "low", "close", "volume"]).drop_duplicates("time") \
      .to_csv(f"../data/XAUUSD_{tf}.csv", index=False)
    print(tf, len(rows), "nen")
