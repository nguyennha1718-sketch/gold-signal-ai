"""Backtest dung CHINH engine live. Khong nhin tuong lai:
- Chi dung nen khung lon DA DONG tai thoi diem phat tin hieu.
- Vao lenh o gia MO nen ke tiep. Chi phi = spread + commission + 2*truot gia (tru vao R).
- Chia train/test theo thoi gian; chi chinh min_score tren TRAIN, bao cao rieng TEST (out-of-sample).
Chay: python backtest.py --data ../data --tf M5 --split 0.7"""
import sys, os, argparse, json
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "backend"))
import numpy as np, pandas as pd
from app import config, indicators as ind, engine as eng, metrics
from app.trade import Trade

def load(path, sym, tf):
    df = pd.read_csv(f"{path}/{sym}_{tf}.csv")
    df["time"] = pd.to_datetime(df["time"], unit="s", utc=True)
    return df.set_index("time")[["open", "high", "low", "close", "volume"]].astype(float)

def run(frames, cfg, start, end, commission=0.07, slippage=0.05):
    etf = cfg["entry_tf"]; E = frames[etf]; sec = config.TF_SECONDS[etf]
    idx = E.index; res = []; busy_until = -1; last_sig_i = -10**9; day_count = {}
    htf_close = {tf: (frames[tf].index + pd.Timedelta(seconds=config.TF_SECONDS[tf])) for tf in frames}
    for i in range(max(start, 250), min(end, len(E) - 2)):
        if i <= busy_until or i - last_sig_i < 3: continue
        t_close = idx[i] + pd.Timedelta(seconds=sec)
        day = t_close.date()
        if day_count.get(day, 0) >= cfg["max_signals_per_day"]: continue
        view = {}
        for tf, F in frames.items():
            n = int(np.searchsorted(htf_close[tf].values, np.datetime64(t_close.tz_convert(None)), side="right"))
            view[tf] = F.iloc[:n]
        r = eng.analyze(view, cfg, live_price=float(E.close.iloc[i]) + (cfg["spread_usd"] / 2))
        sg = r.get("signal")
        if not sg: continue
        nxt = E.iloc[i + 1]; entry = float(nxt.open)
        sgn = 1 if sg["side"] == "BUY" else -1
        if abs(entry - sg["entry"]) > 0.5 * abs(sg["entry"] - sg["sl"]): continue     # truot gia qua lon
        tr = Trade(sg["side"], entry, sg["sl"], [sg["tp1"], sg["tp2"], sg["tp3"]],
                   cost=cfg["spread_usd"] + commission + 2 * slippage)
        j = i + 1
        while j < len(E) and not tr.closed:
            tr.update(float(E.low.iloc[j]), float(E.high.iloc[j])); j += 1
        if not tr.closed: break
        res.append({"time": str(idx[i]), "side": sg["side"], "score": sg["score"], "r": tr.final_r, "outcome": tr.outcome})
        busy_until = j - 1; last_sig_i = i; day_count[day] = day_count.get(day, 0) + 1
    return res

if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--data", default="../data"); ap.add_argument("--sym", default="XAUUSD")
    ap.add_argument("--tf", default="M5"); ap.add_argument("--split", type=float, default=0.7)
    a = ap.parse_args()
    frames = {tf: ind.add_all(load(a.data, a.sym, tf)) for tf in config.TIMEFRAMES}
    cfg = dict(config.DEFAULTS); cfg["entry_tf"] = a.tf
    n = len(frames[a.tf]); cut = int(n * a.split)
    print(f"Du lieu {a.tf}: {n} nen | train: {cut} | test: {n - cut}")
    best, best_exp = None, -9
    for ms in (65, 70, 75, 80):                         # chi 4 gia tri -> han che overfitting
        cfg["min_score"] = ms
        m = metrics.summarize([x["r"] for x in run(frames, cfg, 0, cut)])
        print(f"TRAIN min_score={ms}:", m)
        if m["trades"] >= 30 and m["expectancy_r"] is not None and m["expectancy_r"] > best_exp: best, best_exp = ms, m["expectancy_r"]
    if best is None:
        print("KHONG co cau hinh nao du >=30 lenh & ky vong duong tren TRAIN. KHONG nen dung de giao dich."); sys.exit()
    cfg["min_score"] = best
    test = run(frames, cfg, cut, n)
    print(f"\n=== OUT-OF-SAMPLE (TEST) voi min_score={best} ===")
    print(json.dumps(metrics.summarize([x["r"] for x in test]), indent=2))
    print("Dieu kien dat: >=100 lenh, Expectancy>0, PF>1.3, DD chap nhan duoc -> roi moi forward test DEMO.")
