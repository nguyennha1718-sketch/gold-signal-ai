# GOLD SIGNAL AI – Giai đoạn 2–7 (Backend + App PWA + Backtest)

## Trạng thái
- XONG: engine đa khung (M1–H1), chỉ báo, price action (sweep, FVG, OB, retest, Fib, S/R),
  quản trị rủi ro, theo dõi TP/SL, Telegram, API, cầu nối MT5, backtest.
- XONG (GĐ3): app PWA trong backend/static (Tổng quan, Tín hiệu, Biểu đồ, Hiệu suất, Cài đặt), cài lên màn hình chính.
- Nguồn giá mặc định: Binance PAXGUSDT (không cần khoá, không cần VPS Windows). PAXG là token vàng, KHÔNG phải spot XAUUSD Exness. Chế độ MT5 vẫn còn (DATA_SOURCE=bridge).
- CHƯA: hướng dẫn triển khai chi tiết (GĐ7). Chưa chạy thử với Binance thật (môi trường dựng code không ra được internet).
- PWA cần HTTPS: docker-compose có Caddy tự lấy chứng chỉ, cần 1 tên miền (DuckDNS miễn phí) trỏ về IP máy chủ.
- Backtest không cần MT5: python backtest/download_binance.py 12 rồi python backtest/backtest.py --data ../data --tf M5
- Đã kiểm tra: code chạy end-to-end trên DỮ LIỆU GIẢ. Chưa có bằng chứng nào về hiệu quả trên XAUUSD thật.

## Kiến trúc
VPS Windows (MT5 + mt5_bridge.py) --HTTPS + X-Bridge-Key--> Backend FastAPI (Docker, Linux) + PostgreSQL
Mật khẩu MT5 chỉ ở VPS Windows. Backend chỉ biết BRIDGE_API_KEY.

## Việc phải làm trước khi tin tín hiệu
1. Trên VPS Windows: `python export_history.py 12` -> thư mục data/ (12 tháng M1..H1).
2. Chép data/ về backend, chạy: `python backtest/backtest.py --data data --tf M5`.
3. Chỉ khi OUT-OF-SAMPLE đạt: >=100 lệnh, Expectancy>0, PF>1.3 -> forward test DEMO >=4 tuần.
4. Kiểm tra: tên symbol Exness (XAUUSD/XAUUSDm), SERVER_UTC_OFFSET_HOURS, contract_size, spread/commission thực của loại tài khoản.

## Chạy thử backend (Linux)
cp .env.example .env  (sửa giá trị)  ->  docker compose up -d --build
Bridge (Windows): set BACKEND_URL, BRIDGE_API_KEY rồi `python mt5_bridge.py`

## Giới hạn đã biết
- Không có bộ lọc tin tức (NFP, CPI, FOMC) và phiên giao dịch: nên tự tắt app quanh tin mạnh.
- Backtest dùng nến, không có tick: thứ tự SL/TP trong cùng 1 nến tính SL trước (bảo thủ).
- Cần https (Caddy/Nginx) trước khi mở ra internet.
- Hướng dẫn triển khai: xem HUONG_DAN_TRIEN_KHAI.md (GĐ7 xong, chưa thử trên Oracle thật)
