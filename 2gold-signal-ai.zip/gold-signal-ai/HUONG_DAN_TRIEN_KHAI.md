# Triển khai GOLD SIGNAL AI lên máy chủ miễn phí – chỉ dùng điện thoại Android

Dùng Chrome, bật "Trang web cho máy tính" (⋮ → Trang web cho máy tính) khi vào Oracle và GitHub cho dễ bấm.
Mật khẩu/khóa ở bước nào cũng nên lưu vào trình quản lý mật khẩu.

## Bước 1. Đưa mã nguồn lên GitHub (để máy chủ tải về)
1. Tạo tài khoản tại github.com → New repository → tên `gold-signal` → chọn **Public** → Create.
2. Trong repo: Add file → Upload files → chọn file `gold-signal-ai.zip` (đã tải từ Claude) → Commit.
3. Địa chỉ tải sẽ là: `https://github.com/TÊN_GITHUB_CỦA_BẠN/gold-signal/raw/main/gold-signal-ai.zip`
(Repo công khai chỉ chứa mã nguồn. Mật khẩu của bạn KHÔNG nằm trong đó.)

## Bước 2. Tên miền miễn phí (cần cho HTTPS và để cài app lên màn hình chính)
1. Vào duckdns.org → đăng nhập bằng Google/GitHub.
2. Gõ một tên (vd `vangcuatoi`) → Add domain. Bạn có domain `vangcuatoi.duckdns.org`.
3. Chép **token** hiển thị ở đầu trang.

## Bước 3. (Tùy chọn) Telegram
1. Telegram → tìm @BotFather → /newbot → làm theo → chép **token** bot.
2. Nhắn một tin bất kỳ cho bot của bạn.
3. Mở trình duyệt: `https://api.telegram.org/bot<TOKEN>/getUpdates` → tìm `"chat":{"id":…` → đó là **chat id**.
Bỏ qua bước này cũng được, app vẫn chạy bình thường.

## Bước 4. Tạo máy chủ Oracle Cloud (Always Free)
1. oracle.com/cloud/free → Start for free → đăng ký (cần thẻ Visa/Mastercard để xác minh; Oracle có thể giữ tạm một khoản nhỏ rồi hoàn lại). **Chọn Home region gần bạn (vd Singapore) – không đổi được sau này.**
2. Vào Console → ☰ → Compute → Instances → **Create instance**.
3. Image: **Ubuntu 22.04**. Shape: Change shape → Ampere → `VM.Standard.A1.Flex`, 2 OCPU, 12 GB RAM. (Nếu báo *Out of capacity*: thử lại vài lần hoặc giờ khác; hoặc chọn `VM.Standard.E2.1.Micro`.)
4. Networking: để **Assign a public IPv4 address**.
5. SSH keys: chọn **Generate a key pair** (không cần dùng).
6. **Show advanced options → Management → Paste cloud-init script.**
   Mở file `deploy/bootstrap.sh`, sửa **6 dòng đầu** (ZIP_URL, DOMAIN, DUCK_TOKEN, APP_PASSWORD, TELEGRAM_TOKEN, TELEGRAM_CHAT_ID), dán toàn bộ vào ô này.
7. Create.

## Bước 5. Mở cổng 80 và 443
Console → ☰ → Networking → Virtual cloud networks → chọn VCN → Subnet → **Default Security List → Add Ingress Rules**, thêm 2 luật:
- Source CIDR `0.0.0.0/0`, IP Protocol TCP, Destination port **80**
- Source CIDR `0.0.0.0/0`, IP Protocol TCP, Destination port **443**

## Bước 6. Mở app
Đợi khoảng 10 phút sau khi máy chủ chạy → vào `https://vangcuatoi.duckdns.org` → nhập APP_PASSWORD.
Chrome ⋮ → **Thêm vào màn hình chính** (hoặc "Cài đặt ứng dụng").

## Nếu có lỗi
- **Trang không mở:** chờ thêm vài phút; kiểm tra Bước 5; kiểm tra DuckDNS đã trỏ về IP máy chủ (IP hiện trong trang Instance).
- **Banner đỏ "Lỗi nguồn giá":** gửi nguyên văn dòng lỗi cho Claude (nếu có lỗi 451/403 là Binance chặn khu vực máy chủ).
- **Dữ liệu chưa có tín hiệu:** bình thường. Cần vài giờ nến để đủ dữ liệu, và app chỉ báo khi đủ điều kiện, phần lớn thời gian sẽ là WAIT.
- Nhật ký cài đặt nằm ở `/var/log/gold-bootstrap.log` trên máy chủ (cần SSH, chỉ khi muốn tìm lỗi sâu).

## Quan trọng về an toàn
- Dữ liệu hiện là Binance PAXGUSDT, **chưa phải giá Exness**. Chỉ dùng để xem app chạy và thử nghiệm, chưa vào tiền thật.
- Chưa có bằng chứng chiến lược có lãi. Chạy backtest (backtest/download_binance.py rồi backtest.py) và forward test trên tài khoản demo trước.
- Không phải lời khuyên đầu tư. Không tăng lot để gỡ lỗ.
